# CapstoneProject

Start of the project SoundUp

Tasks : 

Lazlo & Erif & Charlotte
- #1 Generate a bpm aleatory : Done
- #2 update the bpm : Done
- #3 play a music : optional 
- #4 read a file : Done
- #5 change music as the user's bpm progresses : Done (erife)
- #6 define a scenario for the final presentation : not started


task #2 operating mode : to actualise the bpm 
- catch the bpm all the race long
- every 20sec, we change the music : 
    -> compute the average of the 5 last bpm registered 
   

